# rProgressbar
a light wet highly customize able  jQuery plugin for progress bar 

#How to active rProgressbar
